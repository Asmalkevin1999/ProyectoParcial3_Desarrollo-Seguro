import {
  Injectable,
  NestInterceptor,
  ExecutionContext,
  CallHandler,
  Logger,
} from '@nestjs/common';

import { Observable, tap } from 'rxjs';

@Injectable()
export class LoggerInterceptor implements NestInterceptor {

  private readonly logger = new Logger('HTTP');

  intercept(
    context: ExecutionContext,
    next: CallHandler,
  ): Observable<any> {

    const req = context.switchToHttp().getRequest();

    const method = req.method;

    const url = req.url;

    return next.handle().pipe(

      tap(() => {

        this.logger.log(`${method} ${url}`);

      }),

    );

  }

}