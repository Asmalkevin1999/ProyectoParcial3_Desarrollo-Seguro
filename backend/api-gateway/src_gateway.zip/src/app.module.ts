import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { HttpModule } from '@nestjs/axios';

import { HttpConfig, JwtConfig } from './config';

import { AppController } from './app.controller';
import { AppService } from './app.service';

import { AuthModule } from './auth/auth.module';
import { GatewayModule } from './gateway/gateway.module';

import { MasterClient } from './clients/master.client';
import { UserClient } from './clients/user.client';
import { InventoryClient } from './clients/inventory.client';
import { SalesClient } from './clients/sales.client';
import { HrClient } from './clients/hr.client';

import { AuthController } from './controllers/auth.controller';
import { UsersController } from './users/users.controller';
import { InventoryController } from './controllers/inventory.controller';
import { SalesController } from './controllers/sales.controller';
import { HrController } from './controllers/hr.controller';

import { UsersModule } from './users/users.module';

@Module({
  imports: [

    ConfigModule.forRoot({

      isGlobal: true,

      load: [

        HttpConfig,

        JwtConfig,

      ],

    }),

    HttpModule,

    AuthModule,

    UsersModule,

    GatewayModule,

  ],

  controllers: [

    AppController,

    AuthController,

    UsersController,

    InventoryController,

    SalesController,

    HrController,

  ],

  providers: [

    AppService,

    MasterClient,

    UserClient,

    InventoryClient,

    SalesClient,

    HrClient,

  ],

})

export class AppModule {}