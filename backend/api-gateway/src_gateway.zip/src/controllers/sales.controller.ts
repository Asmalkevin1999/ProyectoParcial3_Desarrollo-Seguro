import {
  Controller,
  Get,
  Headers,
} from '@nestjs/common';

import { SalesClient } from '../clients/sales.client';

@Controller('sales')
export class SalesController {

  constructor(
    private readonly salesClient: SalesClient,
  ) {}

  @Get()
  getSales(
    @Headers('authorization') token: string,
  ) {

    return this.salesClient.getSales(token);

  }

}