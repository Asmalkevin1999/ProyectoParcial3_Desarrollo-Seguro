import {
  Controller,
  Get,
  Headers,
} from '@nestjs/common';

import { InventoryClient } from '../clients/inventory.client';

@Controller('inventory')
export class InventoryController {

  constructor(
    private readonly inventoryClient: InventoryClient,
  ) {}

  @Get('products')
  getProducts(
    @Headers('authorization') token: string,
  ) {

    return this.inventoryClient.getProducts(token);

  }

  @Get('categories')
  getCategories(
    @Headers('authorization') token: string,
  ) {

    return this.inventoryClient.getCategories(token);

  }

}