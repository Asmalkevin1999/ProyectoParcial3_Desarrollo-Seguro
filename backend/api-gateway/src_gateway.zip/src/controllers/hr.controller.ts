import {
  Controller,
  Get,
  Headers,
} from '@nestjs/common';

import { HrClient } from '../clients/hr.client';

@Controller('hr')
export class HrController {

  constructor(
    private readonly hrClient: HrClient,
  ) {}

  @Get()
  getEmployees(
    @Headers('authorization') token: string,
  ) {

    return this.hrClient.getEmployees(token);

  }

}