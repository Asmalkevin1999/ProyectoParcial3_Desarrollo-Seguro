import { Injectable } from '@nestjs/common';

import { UserClient } from '../clients/user.client';

@Injectable()
export class UsersService {

  constructor(
    private readonly client: UserClient,
  ) {}

  async findAll(token: string) {
    return await this.client.findAll(token);
  }
}