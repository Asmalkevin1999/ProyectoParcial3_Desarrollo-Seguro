import {
  Controller,
  Get,
  Headers,
} from '@nestjs/common';

import { UsersService } from './users.service';

@Controller('users')
export class UsersController {

  constructor(
    private readonly service: UsersService,
  ) {}

  @Get()
  async findAll(
    @Headers('authorization') token: string,
  ) {
    return await this.service.findAll(token);
  }
}