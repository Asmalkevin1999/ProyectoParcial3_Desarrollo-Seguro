import { Injectable } from '@nestjs/common';
import { HttpService } from '@nestjs/axios';
import { firstValueFrom } from 'rxjs';

@Injectable()
export class HrClient {

  constructor(
    private readonly http: HttpService,
  ) {}

  async getEmployees(token: string) {

    const response = await firstValueFrom(

      this.http.get(
        `${process.env.HR_SERVICE}/employees`,
        {
          headers: {
            Authorization: token,
          },
        },
      ),

    );

    return response.data;

  }

}