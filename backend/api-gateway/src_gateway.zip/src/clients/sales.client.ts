import { Injectable } from '@nestjs/common';
import { HttpService } from '@nestjs/axios';
import { firstValueFrom } from 'rxjs';

@Injectable()
export class SalesClient {

  constructor(
    private readonly http: HttpService,
  ) {}

  async getSales(token: string) {

    const response = await firstValueFrom(

      this.http.get(
        `${process.env.SALES_SERVICE}/sales`,
        {
          headers: {
            Authorization: token,
          },
        },
      ),

    );

    return response.data;

  }

}