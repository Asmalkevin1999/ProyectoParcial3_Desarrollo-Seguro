import { Injectable } from '@nestjs/common';
import { HttpService } from '@nestjs/axios';
import { ConfigService } from '@nestjs/config';

import { firstValueFrom } from 'rxjs';

@Injectable()
export class UserClient {

  private readonly url: string;

  constructor(
    private readonly http: HttpService,
    private readonly config: ConfigService,
  ) {

    this.url = this.config.get<string>(
      'USER_SERVICE',
    )!;

  }

  async findAll(token: string) {

    const response = await firstValueFrom(

      this.http.get(

        `${this.url}/users`,

        {

          headers: {

            Authorization: token,

          },

        },

      ),

    );

    return response.data;

  }

}